 
-- Versiòn 2.0
-- juanperezu.com
-- Laboratorio No.1 SQL 
-- Objetivos
-- Reconocer alguno comando bàsicos de SQL:DDL, DML
-- Reconocer los tipos básicos del motor de bases de datos Mysql
-- Actividad documentar sobre SQL de acuerdo a la base de datos SQL.
--
-- Comentarios SQL
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- Crear si no existe la base de datos bdcampeonato
CREATE DATABASE IF NOT EXISTS bd_campeonato;
-- decir que voy a usar la bd de bdcampeonato 
USE bd_campeonato;
-- Borrar la tabla si existe tblequipo
DROP TABLE IF EXISTS tblequipo;
-- Crear la tabla tblequipo si no existe
-- Not null --> Valor no nulo
-- int valor entero de 2 posiciones
-- char(3) se comporta como un entero 
-- Pero se refiere a los carateres del computar
-- varchar, cadena(String, cadenas) 
-- soportan todo tipo de datos

CREATE TABLE IF NOT EXISTS tblequipo (
  cons int(2) NOT NULL AUTO_INCREMENT,
  nombre varchar(30) NOT NULL,
  categoria char(2) NOT NULL,
  grupo char(4) NOT NULL,
  estado varchar(15) NOT NULL DEFAULT 'Activo',
  capitan varchar(40) NOT NULL,
  PRIMARY KEY (cons)
) ENGINE=InnoDB;
-- PRIMARY KEY: Clave primaria, 
-- es un campo es único dentro de una tabla
-- No se puede repetir produce un error al repetirse de:
-- duplicate entry '' for key 'PRIMARY'
-- ENGINE=Determina la manera como el motor de bases de datos
-- codificará y manejará los datos 
DROP TABLE if EXISTS tbljuez;
CREATE TABLE IF NOT EXISTS tbljuez (
  cons int(2) NOT NULL AUTO_INCREMENT,
  nombre varchar(30) NOT NULL,
  PRIMARY KEY (cons)
) ENGINE=InnoDB;
INSERT INTO tbljuez(cons,nombre)
valueS(null,'JH');
INSERT INTO tbljuez(cons,nombre)
values(null,'Querubin');
INSERT INTO tbljuez(cons,nombre)
values(null,'Pino');
-- INSERT INTO nombretabla: Permite insertar registro en una tabla
INSERT INTO tblequipo (cons, nombre, categoria, grupo, estado, capitan) VALUES
(1, 'Chigorodó', '03', '10.0', 'Activo', 'Felipe Quiros Baena'),
(2, 'Postobon', '03', '11.0', 'Activo', 'Esteban Cardona'),
(3, '200 de cilantro', '03', '06.2', 'Activo', 'Walter Payares'),
(4, 'Vallardygans', '03', '10.0', 'Activo', 'Alexander Vélez'),
(5, 'Equipo 9.1', '03', '9.1', 'Activo', 'Capitan grupo 9.1'),
(6, 'Equipo 9.2', '03', '9.2', 'Activo', 'Capitan grupo 9.2'),
(7, 'Equipo 8.1', '03', '8.1', 'Activo', 'Capitan grupo 8.1'),
(8, 'Equipo 8.2', '03', '8.2', 'Activo', 'Capitan grupo 8.2'),
(9, 'Equipo 7.1', '03', '7.1', 'Activo', 'Capitan grupo 7.1'),
(10, 'Equipo 7.2', '03', '7.2', 'Activo', 'Capitan grupo 7.2'),
(11, 'Equipo 6.1', '03', '6.1', 'Activo', 'Capitan grupo 6.1'),
(12, 'Equipo 6.2', '03', '6.2', 'Activo', 'Capitan grupo 6.2'),
(13, 'Equipo 6.3', '03', '6.3', 'Activo', 'Capitan grupo 6.3');
-- Values: Valores a insertar de un registro
-- AUTO_INCREMENT:Permite generar 
-- valor entero automaticamente
DROP TABLE IF EXISTS tbljugador;
-- 
CREATE TABLE IF NOT EXISTS tbljugador (
  documento int(4) NOT NULL AUTO_INCREMENT,
  nombres varchar(30) NOT NULL,
  apellidos varchar(30) NOT NULL,
  genero char(1) NOT NULL,
  codigo_equipo int(2) NOT NULL,
  PRIMARY KEY (documento)
) ENGINE=InnoDB;
--  
INSERT INTO tbljugador (documento, nombres, apellidos, genero, codigo_equipo) VALUES
(1, 'Juan Felipe', 'Quiros Baena', 'M', 1),
(2, 'A', 'Apellido A', 'M', 1),
(3, 'B', 'Apellido B', 'M', 1),
(4, 'C', 'Apellido c', 'M', 1),
(5, 'd', 'Apellido d', 'M', 1),
(6, 'e', 'Apellido e', 'M', 1),
(7, 'f', 'Apellido f', 'M', 1),
(8, 'g', 'Apellido g', 'M', 1),
(9, 'B', 'Apellido B', 'M', 2),
(10, 'C', 'Apellido c', 'M', 2),
(11, 'd', 'Apellido d', 'M', 2),
(12, 'e', 'Apellido e', 'M', 2),
(13, 'f', 'Apellido f', 'M', 2),
(14, 'g', 'Apellido g', 'M', 2),
(15, 'g', 'Apellido g', 'M', 2),
(16, 'g', 'Apellido g', 'M', 2),
(19, 'g', 'Apellido g', 'M', 3),
(20, 'g', 'Apellido g', 'M', 3),
(21, 'g', 'Apellido g', 'M', 3),
(22, 'g', 'Apellido g', 'M', 3),
(23, 'g', 'Apellido g', 'M', 3),
(24, 'g', 'Apellido g', 'M', 3),
(25, 'NombA', 'Apellidos A', 'M', 4),
(26, 'NombB', 'Apellidos B', 'M', 4),
(27, 'NombC', 'Apellidos C', 'M', 4),
(28, 'NombD', 'Apellidos D', 'M', 4),
(29, 'NombE', 'Apellidos E', 'M', 4),
(30, 'NombF', 'Apellidos F', 'M', 4),
(31, 'NombG', 'Apellidos G', 'M', 4),
(32, 'NombH', 'Apellidos H', 'M', 4),
(33, 'nombre', 'apellid', 'M', 5),
(34, 'nombre', 'apellid', 'M', 5),
(35, 'nombre', 'apellid', 'M', 5),
(36, 'nombre', 'apellid', 'M', 5),
(37, 'nombre', 'apellid', 'M', 5),
(38, 'nombre', 'apellid', 'M', 5),
(39, 'nombre', 'apellid', 'M', 5),
(40, 'nombre', 'apellid', 'M', 5),
(41, 'nombre', 'apellid', 'M', 6),
(42, 'nombre', 'apellid', 'M', 6),
(43, 'nombre', 'apellid', 'M', 6),
(44, 'nombre', 'apellid', 'M', 6),
(45, 'nombre', 'apellid', 'M', 6),
(46, 'nombre', 'apellid', 'M', 6),
(47, 'nombre', 'apellid', 'M', 6),
(48, 'nombre', 'apellid', 'M', 6),
(49, 'nombre', 'apellid', 'M', 7),
(50, 'nombre', 'apellid', 'M', 7),
(51, 'nombre', 'apellid', 'M', 7),
(52, 'nombre', 'apellid', 'M', 7),
(53, 'nombre', 'apellid', 'M', 7),
(54, 'nombre', 'apellid', 'M', 7),
(55, 'nombre', 'apellid', 'M', 7),
(56, 'nombre', 'apellid', 'M', 7),
(57, 'nombre', 'apellid', 'M', 8),
(58, 'nombre', 'apellid', 'M', 8),
(59, 'nombre', 'apellid', 'M', 8),
(60, 'nombre', 'apellid', 'M', 8),
(61, 'nombre', 'apellid', 'M', 8),
(62, 'nombre', 'apellid', 'M', 8),
(63, 'nombre', 'apellid', 'M', 8),
(64, 'nombre', 'apellid', 'M', 8),
(65, 'nombre', 'apellid', 'M', 9),
(66, 'nombre', 'apellid', 'M', 9),
(67, 'nombre', 'apellid', 'M', 9),
(68, 'nombre', 'apellid', 'M', 9),
(69, 'nombre', 'apellid', 'M', 9),
(70, 'nombre', 'apellid', 'M', 9),
(71, 'nombre', 'apellid', 'M', 9),
(72, 'nombre', 'apellid', 'M', 9),
(73, 'nombre', 'apellid', 'M', 10),
(74, 'nombre', 'apellid', 'M', 10),
(75, 'nombre', 'apellid', 'M', 10),
(76, 'nombre', 'apellid', 'M', 10),
(77, 'nombre', 'apellid', 'M', 10),
(78, 'nombre', 'apellid', 'M', 10),
(79, 'nombre', 'apellid', 'M', 10),
(80, 'nombre', 'apellid', 'M', 10),
(81, 'nombre', 'apellid', 'M', 11),
(82, 'nombre', 'apellid', 'M', 11),
(83, 'nombre', 'apellid', 'M', 11),
(84, 'nombre', 'apellid', 'M', 11),
(85, 'nombre', 'apellid', 'M', 11),
(86, 'nombre', 'apellid', 'M', 11),
(87, 'nombre', 'apellid', 'M', 11),
(88, 'nombre', 'apellid', 'M', 11),
(89, 'nombre', 'apellid', 'M', 12),
(90, 'nombre', 'apellid', 'M', 12),
(91, 'nombre', 'apellid', 'M', 12),
(92, 'nombre', 'apellid', 'M', 12),
(93, 'nombre', 'apellid', 'M', 12),
(94, 'nombre', 'apellid', 'M', 12),
(95, 'nombre', 'apellid', 'M', 12),
(96, 'nombre', 'apellid', 'M', 12),
(97, 'nombre', 'apellid', 'M', 13),
(98, 'nombre', 'apellid', 'M', 13),
(99, 'nombre', 'apellid', 'M', 13),
(100, 'nombre', 'apellid', 'M', 13),
(101, 'nombre', 'apellid', 'M', 13),
(102, 'nombre', 'apellid', 'M', 13),
(103, 'nombre', 'apellid', 'M', 13),
(104, 'nombre', 'apellid', 'M', 13);
-- Otorgar todos los privilegios a un usuario
-- llamado Juan a la base datos bd_campeonato a nivel local
GRANT ALL ON  bd_campeonato.* TO juan@localhost IDENTIFIED BY "12345678";

-- Otorgar todos los privilegios a un usuario
-- llamado Juan a la base datos bd_campeonato a nivel remoto

GRANT ALL ON bd_campeonato.* TO 'juan'@'%' IDENTIFIED BY '12345678'; 

-- 1.Seleccionar todos los datos del jugador 100
SELECT * FROM tbljugador WHERE documento=100;
-- 2. Seleccionar todos los estudiantes incluidos en el equipo 1
SELECT * FROM tbljugador WHERE codigo_equipo=1;
-- 3.Seleccionar el nombre de los estudiantes del equipo 1
SELECT nombres FROM tbljugador WHERE codigo_equipo=1;
-- Describaba los tipos de datos de Mysql
-- Numericos: longitud
-- varchar:
-- Text:
-- Fecha: 
-- BOOLEAN
-- real:

-- Cadena:
-- Espacial:
-- json    
    


