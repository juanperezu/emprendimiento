<div class="container p-4">
    <div class="row">
        
        {{#each links}}
        <div class="col-md-3">
            <div class="card text-center">
                
                <div class="card-body">
                    <a href="{{url}}" target="_blank">
                        <h3 class="card-title text-uppercase">
                            {{title}}
                        </h3>
                    </a>
                    <p class="m-2">{{description}}</p>
                    <p class="text-muted">
                        {{timeago created_at}}
                    </p>
                    <a class="btn btn-light" href="/links/delete/{{id}}">
                       <img src="/img/del.png" title="Borrar Equipo"/>
                    </a>
                    <a class="btn btn-light" href="/links/edit/{{id}}">
                         <img src="/img/edit.png" title="Editar Equipo"/>
                    </a>
                </div>
            </div>
        </div>
        {{else}}
        <div class="col-md-4 mx-auto">
            <div class="card card-body text-center">
                <p>No hay equipos.</p>
                <a href="/links/add">Crear equipo!</a>
            </div>
        </div>
        {{/each}}
    </div>
</div>