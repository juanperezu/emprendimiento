<?
$id = base64_decode($_REQUEST['id']); 
include 'config/Conexion.php';
  $sql="SELECT id_propietario, nombre, telefono, correo FROM propietarios
        WHERE id_propietario ='$id'";
  $consulta=mysqli_query($con,$sql);
  $nfilas=mysqli_num_rows($consulta);
  while($reg=mysqli_fetch_array($consulta)){
       $nombre=$reg['nombre'];
       $correo =$reg['correo'];
   }// fin mientras
  mysqli_close($con);
?>

<div class="col-md-4 mx-auto">

    <div class="card">
        <div class="card-body">
            <form action="/links/edit/{{link.id}}" method="POST">
                <div class="form-group">
                    <input type="text" name="title" class="form-control" placeholder="Title" value="{{link.title}}" autofocus>
                </div>
                <div class="form-group">
                    <input type="url" name="url" class="form-control" placeholder="URL" value="{{link.url}}">
                </div>
                <div class="form-group">
                    <textarea name="description" rows="2" class="form-control" placeholder="Description">{{link.description}}</textarea>
                </div>
                <div class="form-group">
                    <button class="btn btn-success btn-block">
                         <img src="/img/save.png" title="Salvar Equipo"/>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>