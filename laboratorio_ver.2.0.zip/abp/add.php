<div class="container p-4">
    <div class="row">
        <div class="col-md-4 mx-auto">

            <div class="card">
                <div class="card-body">
                    <form action="/links/add" method="POST">
                        <div class="form-group">
                            <input type="text" name="title" class="form-control" placeholder="Title" autofocus>
                        </div>
                        <div class="form-group">
                            <input type="url" name="url" class="form-control" placeholder="URL">
                        </div>
                        <div class="form-group">
                            <textarea name="description" rows="2" class="form-control" placeholder="Description"></textarea>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success btn-block">
                                Save
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>