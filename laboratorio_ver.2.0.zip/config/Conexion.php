<?
    
$host="b1dccfhhk6a41y9qoebc-mysql.services.clever-cloud.com";
//localhost,127.0,01,ip red
$user="u7gkwvswwe3u1e5z";
$pwd="5rAwJBNKfZElhvMCZbw5";
$db="b1dccfhhk6a41y9qoebc";
$con =mysqli_connect($host,$user,$pwd,$db) or
  die("Error en la conexión");
?>