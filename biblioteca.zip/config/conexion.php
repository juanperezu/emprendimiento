<?
$host="bz0zity9ealvkwxfmk2j-mysql.services.clever-cloud.com";
$bd="bz0zity9ealvkwxfmk2j";
$user="u8rkwowg5ofzowyf";
$pwd="IHvhg7ifrao3MaNkSg24";
$con=mysqli_connect($host,$user,$pwd,$bd) or 
  die(" Problemas en la conexión");
?>