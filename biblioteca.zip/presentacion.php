<div class="jumbotron text-center sm-4">
  <h1>Biblioteca</h1>
  <p>
<img src="img/biblioteca.png">
    
  </p> 
</div>