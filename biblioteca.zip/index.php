
<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>
<?include 'presentacion.php'?>

<div class="container">
   <div class="row">
   <?include 'columna1.php';
     include 'columna2.php';
    ?>
  </div>
<div class ="row">
  <?include 'editoriales.php'?>
</div>
</div>
</body>
</html>
