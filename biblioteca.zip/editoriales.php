<div class="col-sm-8">
 <h3>Principales Editoriales</h3> 
<?

$sql="SELECT codigo,nombre,logo  
       FROM tbleditorial ";  

// incluir conexion
include 'config/conexion.php';
$registro=mysqli_query($con,$sql) or die('Error en sql');
echo '<center><table><tr><td>codigo</td><td>Nombre</td><td></td></tr>';
while($r=mysqli_fetch_array($registro)){
  echo "<tr><td>".$r['codigo']."</td><td>".$r['nombre']."</td>
        <td><img src=img/".$r['logo']."></td>
        </tr>";
}
?>

</table></center>
    </div>